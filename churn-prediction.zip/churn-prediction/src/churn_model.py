"""
Customer Churn Prediction Pipeline
==================================
Steps
  1. Load dataset, clean, and encode features (One-Hot + MinMax scaling)
  2. Stratified 80/20 train-test split
  3. Train Logistic Regression and Random Forest classifiers
  4. Evaluate with Precision, Recall, F1-Score and ROC-AUC (+ ROC curve)
  5. Export customer churn risk scores

Usage (from the repository root):
    python src/churn_model.py --data data/churn.csv --out outputs
"""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless-safe backend (works in Colab, servers, CI)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder

RANDOM_STATE = 42
TARGET = "Churn"
ID_COL = "CustomerID"

NUMERIC_FEATURES = [
    "Age",
    "TenureMonths",
    "MonthlyChargesINR",
    "TotalChargesINR",
    "SupportTickets",
    "LatePayments",
]
CATEGORICAL_FEATURES = [
    "Region",
    "SubscriptionType",
    "ContractType",
    "PaymentMethod",
    "AutoPay",
]


# --------------------------------------------------------------------------
# 1. Load + clean
# --------------------------------------------------------------------------
def load_data(path: str) -> pd.DataFrame:
    # sep=None lets pandas auto-detect comma / tab / semicolon separated files
    df = pd.read_csv(path, sep=None, engine="python")
    df.columns = [c.strip() for c in df.columns]

    required = [ID_COL, TARGET] + NUMERIC_FEATURES + CATEGORICAL_FEATURES
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {missing}")

    df = df.drop_duplicates(subset=ID_COL).reset_index(drop=True)
    for col in CATEGORICAL_FEATURES + [TARGET]:
        df[col] = df[col].astype(str).str.strip()
    for col in NUMERIC_FEATURES:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Target: Yes -> 1, No -> 0
    df[TARGET] = df[TARGET].map({"Yes": 1, "No": 0})
    if df[TARGET].isna().any():
        raise ValueError("Churn column must contain only 'Yes' / 'No' values.")
    df[TARGET] = df[TARGET].astype(int)
    return df


# --------------------------------------------------------------------------
# 2. Preprocessing (One-Hot + MinMax) -- fitted inside the pipeline so that
#    statistics come from the training split only (no data leakage).
# --------------------------------------------------------------------------
def build_preprocessor() -> ColumnTransformer:
    from sklearn.impute import SimpleImputer

    numeric_pipe = Pipeline(
        [
            ("impute", SimpleImputer(strategy="median")),
            ("scale", MinMaxScaler()),
        ]
    )
    categorical_pipe = Pipeline(
        [
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )
    return ColumnTransformer(
        [
            ("num", numeric_pipe, NUMERIC_FEATURES),
            ("cat", categorical_pipe, CATEGORICAL_FEATURES),
        ]
    )


def build_models() -> dict:
    return {
        "Logistic Regression": Pipeline(
            [
                ("prep", build_preprocessor()),
                (
                    "clf",
                    LogisticRegression(
                        max_iter=1000,
                        class_weight="balanced",
                        random_state=RANDOM_STATE,
                    ),
                ),
            ]
        ),
        "Random Forest": Pipeline(
            [
                ("prep", build_preprocessor()),
                (
                    "clf",
                    RandomForestClassifier(
                        n_estimators=300,
                        max_depth=8,
                        min_samples_leaf=5,
                        class_weight="balanced",
                        random_state=RANDOM_STATE,
                        n_jobs=-1,
                    ),
                ),
            ]
        ),
    }


# --------------------------------------------------------------------------
# 4. Evaluation helpers
# --------------------------------------------------------------------------
def evaluate(model, X_test, y_test) -> dict:
    proba = model.predict_proba(X_test)[:, 1]
    pred = (proba >= 0.5).astype(int)
    return {
        "precision": precision_score(y_test, pred, zero_division=0),
        "recall": recall_score(y_test, pred, zero_division=0),
        "f1": f1_score(y_test, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_test, proba),
    }, proba, pred


def risk_band(p: float) -> str:
    if p >= 0.66:
        return "High"
    if p >= 0.33:
        return "Medium"
    return "Low"


def feature_importance(model: Pipeline) -> pd.DataFrame:
    names = model.named_steps["prep"].get_feature_names_out()
    clf = model.named_steps["clf"]
    if hasattr(clf, "feature_importances_"):
        vals = clf.feature_importances_
        kind = "importance"
    else:
        vals = clf.coef_[0]
        kind = "coefficient"
    out = pd.DataFrame({"feature": names, kind: vals})
    return out.reindex(out[kind].abs().sort_values(ascending=False).index)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main(data_path: str, out_dir: str) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    df = load_data(data_path)
    print(f"Loaded {len(df):,} customers | churn rate = {df[TARGET].mean():.1%}")

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df[TARGET]

    # 2. 80/20 stratified split
    X_train, X_test, y_train, y_test, id_train, id_test = train_test_split(
        X, y, df[ID_COL], test_size=0.20, stratify=y, random_state=RANDOM_STATE
    )
    print(f"Train: {len(X_train)} rows | Test: {len(X_test)} rows")

    # 3 + 4. Train and evaluate every model
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    models = build_models()
    results, fitted, probas = [], {}, {}

    for name, model in models.items():
        cv_auc = cross_val_score(model, X_train, y_train, cv=cv, scoring="roc_auc")
        model.fit(X_train, y_train)
        metrics, proba, pred = evaluate(model, X_test, y_test)
        fitted[name], probas[name] = model, proba

        results.append({"model": name, "cv_roc_auc_mean": cv_auc.mean(),
                        "cv_roc_auc_std": cv_auc.std(), **metrics})

        print(f"\n===== {name} =====")
        print(f"5-fold CV ROC-AUC (train): {cv_auc.mean():.3f} +/- {cv_auc.std():.3f}")
        print(classification_report(y_test, pred, target_names=["Stay", "Churn"], zero_division=0))
        print(f"Test ROC-AUC: {metrics['roc_auc']:.3f}")

        # confusion matrix plot
        fig, ax = plt.subplots(figsize=(4.5, 4))
        ConfusionMatrixDisplay(confusion_matrix(y_test, pred),
                               display_labels=["Stay", "Churn"]).plot(ax=ax, colorbar=False)
        ax.set_title(f"Confusion Matrix - {name}")
        fig.tight_layout()
        fig.savefig(out / f"confusion_matrix_{name.replace(' ', '_').lower()}.png", dpi=150)
        plt.close(fig)

    results_df = pd.DataFrame(results).round(4)
    results_df.to_csv(out / "model_comparison.csv", index=False)
    print("\n", results_df.to_string(index=False))

    # ROC curves (both models on one plot)
    fig, ax = plt.subplots(figsize=(6, 5))
    for name, proba in probas.items():
        fpr, tpr, _ = roc_curve(y_test, proba)
        ax.plot(fpr, tpr, label=f"{name} (AUC = {roc_auc_score(y_test, proba):.3f})")
    ax.plot([0, 1], [0, 1], "k--", label="Random guess")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve - Churn Prediction (Test Set)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(out / "roc_curve.png", dpi=150)
    plt.close(fig)

    # Select the best model by test ROC-AUC
    best_name = results_df.sort_values("roc_auc", ascending=False).iloc[0]["model"]
    best = fitted[best_name]
    print(f"\nBest model by ROC-AUC: {best_name}")

    fi = feature_importance(best)
    fi.to_csv(out / "feature_importance.csv", index=False)

    # 5. Export churn risk scores for ALL customers with the best model
    all_proba = best.predict_proba(X)[:, 1]
    scores = pd.DataFrame(
        {
            ID_COL: df[ID_COL],
            "ChurnRiskScore": all_proba.round(4),
            "RiskBand": [risk_band(p) for p in all_proba],
            "PredictedChurn": np.where(all_proba >= 0.5, "Yes", "No"),
            "ActualChurn": np.where(y == 1, "Yes", "No"),
            "Split": np.where(df[ID_COL].isin(set(id_test)), "test", "train"),
        }
    ).sort_values("ChurnRiskScore", ascending=False)
    scores.to_csv(out / "churn_risk_scores.csv", index=False)

    # Held-out (unbiased) predictions only
    scores[scores["Split"] == "test"].to_csv(out / "churn_risk_scores_test_only.csv", index=False)

    with open(out / "metrics.json", "w") as f:
        json.dump({"best_model": best_name, "results": results_df.to_dict(orient="records")}, f, indent=2)

    print(f"\nSaved all outputs to: {out.resolve()}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Customer churn prediction pipeline")
    parser.add_argument("--data", default="data/churn.csv", help="Path to churn dataset")
    parser.add_argument("--out", default="outputs", help="Output directory")
    args = parser.parse_args()
    main(args.data, args.out)
