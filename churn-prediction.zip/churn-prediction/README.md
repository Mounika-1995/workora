# Customer Churn Prediction (Logistic Regression vs Random Forest)

Machine learning pipeline that forecasts each customer's churn probability
and ranks customers by retention risk.

## Project structure

```
churn-prediction/
├── data/churn.csv              # <- place the dataset here
├── src/churn_model.py          # full pipeline (preprocess, train, evaluate, export)
├── outputs/                    # generated: metrics, plots, risk scores
├── requirements.txt
└── README.md
```

## Dataset

800 customers, 13 columns.

| Column | Type | Description |
|---|---|---|
| CustomerID | ID | Dropped before modelling |
| Age, TenureMonths, MonthlyChargesINR, TotalChargesINR, SupportTickets, LatePayments | Numeric | MinMax scaled |
| Region, SubscriptionType, ContractType, PaymentMethod, AutoPay | Categorical | One-Hot encoded |
| Churn | Target | Yes = 1, No = 0 |

## How to run

```bash
pip install -r requirements.txt
python src/churn_model.py --data data/churn.csv --out outputs
```

### Google Colab

```python
!git clone https://github.com/<your-username>/churn-prediction.git
%cd churn-prediction
!pip install -q -r requirements.txt
!python src/churn_model.py --data data/churn.csv --out outputs
```

## Methodology

1. **Preprocessing** - One-Hot encoding for categorical columns, MinMax scaling for
   numeric columns, median/mode imputation as a safety net. All of this sits inside a
   scikit-learn `Pipeline`, so scaling statistics are learned from the training split
   only (no data leakage).
2. **Split** - 80/20 train-test split, stratified on `Churn`, `random_state=42`.
3. **Models** - Logistic Regression and Random Forest, both with
   `class_weight="balanced"`. 5-fold stratified cross-validation (ROC-AUC) on the
   training set for a stable estimate.
4. **Evaluation** - Precision, Recall, F1-Score (threshold 0.5) and ROC-AUC on the
   held-out test set, plus ROC curve and confusion matrices.
5. **Export** - Churn probability for every customer from the best model (by test
   ROC-AUC), with risk bands: Low < 0.33, Medium 0.33 to 0.66, High >= 0.66.

## Outputs (in `outputs/`)

| File | Content |
|---|---|
| `model_comparison.csv`, `metrics.json` | Precision, Recall, F1, ROC-AUC for both models |
| `roc_curve.png` | ROC curves of both models |
| `confusion_matrix_*.png` | Confusion matrix per model |
| `feature_importance.csv` | Coefficients / importances of the best model |
| `churn_risk_scores.csv` | Risk score, band and prediction for all customers |
| `churn_risk_scores_test_only.csv` | Same, restricted to unseen test customers |

## Results

Run the script and paste your numbers from `outputs/model_comparison.csv` here:

| Model | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|
| Logistic Regression | | | | |
| Random Forest | | | | |

Insert `outputs/roc_curve.png` here:
`![ROC](outputs/roc_curve.png)`

## Notes and limitations

- `TotalChargesINR` is roughly `TenureMonths x MonthlyChargesINR`, so the two are
  strongly correlated. This does not hurt tree models and only mildly affects
  Logistic Regression coefficients.
- Scores in `churn_risk_scores.csv` for rows with `Split = train` are in-sample and
  optimistic. Use `churn_risk_scores_test_only.csv` for honest performance claims.
- With only 800 rows, metrics vary with the random split. The cross-validation
  columns give a more stable picture.
- A 0.5 threshold is a default. For retention campaigns, lower it to catch more
  churners (higher recall) at the cost of precision.
